SELECT "name" , "city" FROM "schools" WHERE "type" = "Public School" AND "state" = "MA";

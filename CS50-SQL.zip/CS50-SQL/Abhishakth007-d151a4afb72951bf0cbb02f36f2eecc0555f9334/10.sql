SELECT "english_title" as "Titles in order of brightness by HOKUSAI" FROM "views" WHERE "artist" = "Hokusai" ORDER BY "brightness" DESC;


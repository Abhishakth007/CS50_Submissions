SELECT COUNT("english_title") FROM "views" WHERE "english_title" LIKE '%Fuji%'  AND "artist" LIKE "Hokusai";

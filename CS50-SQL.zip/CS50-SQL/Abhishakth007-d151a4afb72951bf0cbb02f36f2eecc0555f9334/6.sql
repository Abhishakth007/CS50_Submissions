SELECT ROUND(AVG("entropy"),2) as "Hiroshige Average Entropy" FROM "views" WHERE "artist" LIKE "Hiroshige";

SELECT "average_color" FROM "views" WHERE "artist" LIKE "Hokusai" AND "english_title" LIKE "%river%";

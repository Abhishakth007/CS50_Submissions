SELECT COUNT(*) FROM "views"  WHERE "artist" LIKE "Hiroshige" AND "english_title" LIKE "%Eastern Capital%";

SELECT MAX("contrast") as "Maximum Contrast" FROM "views" WHERE "artist"= "Hokusai";

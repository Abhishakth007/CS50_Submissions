SELECT "bats" FROM "players" WHERE "first_name" LIKE "Babe" AND "last_name" LIKE "Ruth";

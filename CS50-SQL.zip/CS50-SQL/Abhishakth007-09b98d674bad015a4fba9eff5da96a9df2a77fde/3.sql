SELECT "id"  FROM "players" WHERE "debut" IS NULL;

SELECT "birth_city" , "birth_state","birth_country" FROM "players" WHERE "first_name" LIKE "Jackie" AND "last_name" LIKE "Robinson";

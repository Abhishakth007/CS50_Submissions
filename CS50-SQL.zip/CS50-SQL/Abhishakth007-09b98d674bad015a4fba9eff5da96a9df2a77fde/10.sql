SELECT "first_name" as 'Name' FROM "players" WHERE "debut" > "2020-01-01" ORDER BY "first_name" LIMIT 10;


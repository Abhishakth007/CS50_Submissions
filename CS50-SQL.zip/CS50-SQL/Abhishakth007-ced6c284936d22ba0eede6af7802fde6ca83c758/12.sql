SELECT COUNT(DISTINCT "title") FROM "episodes";

SELECT "title" FROM "episodes" WHERE "season" = 6 AND "air_date" BETWEEN "2007-01-01" AND "2007-12-31";

SELECT  "title" from "episodes" WHERE "season"=1;

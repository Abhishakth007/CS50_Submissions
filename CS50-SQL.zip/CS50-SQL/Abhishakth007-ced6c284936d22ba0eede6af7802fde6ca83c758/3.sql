SELECT "production_code" FROM "episodes" WHERE "title"= "Hackerized!";

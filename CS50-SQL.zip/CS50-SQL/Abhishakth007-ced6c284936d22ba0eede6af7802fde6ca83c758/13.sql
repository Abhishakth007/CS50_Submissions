SELECT "title" FROM "episodes" WHERE "air_date" < "2007-01-01" AND  "air_date" > "2006-01-01";
